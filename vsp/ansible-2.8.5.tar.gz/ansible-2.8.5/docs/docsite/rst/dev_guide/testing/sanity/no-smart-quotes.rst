no-smart-quotes
===============

Smart quotes (``”“‘’``) should not be used.  Use plain ascii quotes (``"'``) instead.
